const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
let UNIT_CALIBRATION = {
    "basic": { s: 2.15, unitX: 0, unitY: -18, eyeX: 0, eyeY: -30, textX: 0, textY: -2, upgX: 25, upgY: 10, menuX: 0, menuY: -75 },
    "building_1": { s: 2.75, unitX: 0, unitY: -30, eyeX: 0, eyeY: -30, textX: 0, textY: -4, upgX: 29, upgY: 9, menuX: 0, menuY: -75 },
    "building_2": { s: 2.9, unitX: 2, unitY: -30, eyeX: 0, eyeY: -30, textX: 0, textY: -4, upgX: 28, upgY: 10, menuX: 0, menuY: -75 },
    "building_3": { s: 3.1, unitX: 0, unitY: -35, eyeX: 0, eyeY: -30, textX: 0, textY: -4, upgX: 28, upgY: 10, menuX: 0, menuY: -75 },
    "building_4": { s: 3, unitX: 0, unitY: -36, eyeX: 0, eyeY: -30, textX: 0, textY: -4, upgX: 31, upgY: 9, menuX: 0, menuY: -75 },
    "building_5": { s: 3.2, unitX: -2, unitY: -37, eyeX: 0, eyeY: -30, textX: 0, textY: -5, upgX: 35, upgY: 9, menuX: 0, menuY: -55 },
    "fort_1": { s: 2.1, unitX: 1, unitY: -15, eyeX: 0, eyeY: -25, textX: 0, textY: -2, upgX: 34, upgY: 10, menuX: 0, menuY: -70 },
    "fort_2": { s: 2.4, unitX: 0, unitY: -18, eyeX: 0, eyeY: -26, textX: 0, textY: -2, upgX: 32, upgY: 10, menuX: 0, menuY: -70 },
    "fort_3": { s: 2.9, unitX: 8, unitY: -18, eyeX: 0, eyeY: -30, textX: 0, textY: -4, upgX: 34, upgY: 10, menuX: 0, menuY: -70 },
    "lab_1": { s: 3.15, unitX: 0, unitY: -20, eyeX: 0, eyeY: -18, textX: 0, textY: 5, upgX: 36, upgY: 10, menuX: 0, menuY: -65 },
    "lab_2": { s: 2.6, unitX: 5, unitY: -20, eyeX: 0, eyeY: -20, textX: 0, textY: 2, upgX: 35, upgY: 10, menuX: 0, menuY: -65 },
    "lab_3": { s: 3.3, unitX: -2, unitY: -12, eyeX: 0, eyeY: -20, textX: 0, textY: 2, upgX: 35, upgY: 10, menuX: 0, menuY: -65}
};

app.use(express.static(__dirname));

const BUILDING_CONFIGS = { 
    basic: { 
        maxJellies: 10, 
        prodRate: 0.05, 
        upgrades: [{ target: 'building', cost: 5 }, 
                   { target: 'fort', cost: 10 }, 
                   { target: 'lab', cost: 10 }] },
    building: { 
        1: { maxJellies: 10 , prodRate: 0.08, upgradeCost: 5 }, 
        2: { maxJellies: 20 , prodRate: 0.12, upgradeCost: 10 }, 
        3: { maxJellies: 30 , prodRate: 0.16, upgradeCost: 20 }, 
        4: { maxJellies: 40 , prodRate: 0.20, upgradeCost: 30 }, 
       5: { maxJellies: 50 , prodRate: 0.25, upgradeCost: null } },
    fort: { 
        1: { maxJellies: 60, prodRate: 0.0, defense: 3.0, upgradeCost: 20, cooldownTicks: 20 }, // 2 seconds
        2: { maxJellies: 80, prodRate: 0.0, defense: 3.5, upgradeCost: 25, cooldownTicks: 15 }, 
        3: { maxJellies: 100, prodRate: 0.0, defense: 4.0, upgradeCost: null, cooldownTicks: 10 } // 1.0 second  
    },
    lab: {  
        1: { maxJellies: 50 , prodRate: 0.0 , upgradeCost: 15 }, 
        2: { maxJellies: 100, prodRate: 0.0 , upgradeCost: 20 }, 
        3: { maxJellies: 150, prodRate: 0.0 , upgradeCost: null } }
};

const POTION_CONFIGS = { 
    freeze: { cost: 25, craftDurationTicks: 50 }, 
    virus: { cost: 30, craftDurationTicks: 80 }, 
    red: { cost: 50, craftDurationTicks: 120 } };

// Dictionary to hold all active matches
let rooms = {}; 

// Helper function to generate a 5-letter room code
function generateRoomCode() {
    return Math.random().toString(36).substring(2, 7).toUpperCase();
}


// Utility to find which room a socket is in
function getPlayerRoom(socket) {
    return Array.from(socket.rooms).find(r => r !== socket.id);
}

// --- GET EXACT VISUAL CENTER OF A UNIT ---
function getUnitVisualCenter(b) {
    const pathKey = b.type === 'basic' ? 'basic' : `${b.type}_${b.level || 1}`;
    const calib = (typeof UNIT_CALIBRATION !== 'undefined' && UNIT_CALIBRATION[pathKey]) ? UNIT_CALIBRATION[pathKey] : {};

    // 1. Start with the base position + general offset
    const baseX = b.x + (calib.offsetX || 0);
    const baseY = b.y + (calib.offsetY || 0);

    // 2. Add the specific Eyes offset
    const eyesX = baseX + (calib.eyesX !== undefined ? calib.eyesX : 0);
    const eyesY = baseY + (calib.eyesY !== undefined ? calib.eyesY : -15);

    // 3. Add the specific Text/Jelly value offset
    // (Checking both textX/Y and jellyX/Y depending on how you named them)
    const textX = baseX + (calib.textX !== undefined ? calib.textX : (calib.jellyX || 0));
    const textY = baseY + (calib.textY !== undefined ? calib.textY : (calib.jellyY || 15));

    // 4. Return the perfect middle point between them
    return {
        x: (eyesX + textX) / 2,
        y: (eyesY + textY) / 2
    };
}


io.on('connection', (socket) => {

    // --- NETWORK PING CALCULATOR ---
    socket.on('pingResponse', (timestamp) => {
        const roomCode = getPlayerRoom(socket);
        if (roomCode && rooms[roomCode]) {
            const player = rooms[roomCode].players[socket.id];
            if (player) {
                // Calculate exactly how many milliseconds it took to reply
                player.ping = Date.now() - timestamp; 
            }
        }
    });

    // --- HOST CHOOSES / CHANGES MAP IN LOBBY ---
    socket.on('setRoomMap', (data) => {
        const roomCode = getPlayerRoom(socket);
        if (!roomCode || !rooms[roomCode] || rooms[roomCode].host !== socket.id) return;

        let parsedBuildings = data.mapData.buildings || data.mapData || [];
        let parsedSettings = data.mapData.settings || { mapScale: 100 };

        // Sanitize building levels
        if (Array.isArray(parsedBuildings) && parsedBuildings.length > 0) {
            parsedBuildings.forEach(b => {
                if (b.type === 'basic') {
                    b.level = 1;
                } else if (BUILDING_CONFIGS[b.type]) {
                    const availableLevels = Object.keys(BUILDING_CONFIGS[b.type]).map(Number).filter(n => !isNaN(n));
                    const maxLevel = Math.max(...availableLevels);
                    if (b.level > maxLevel || !BUILDING_CONFIGS[b.type][b.level]) {
                        b.level = maxLevel;
                    }
                }
            });
        }

        rooms[roomCode].state.settings = parsedSettings;
        rooms[roomCode].state.buildings = parsedBuildings;
        rooms[roomCode].mapName = data.mapName; // NEW: Save the map name!

        io.to(roomCode).emit('lobbyUpdate', {
            players: Object.values(rooms[roomCode].players),
            host: rooms[roomCode].host,
            hasMap: rooms[roomCode].state.buildings.length > 0,
            mapName: rooms[roomCode].mapName, // NEW: Send the name to everyone!
            mapData: rooms[roomCode].state
        });
    });    
// --- LOBBY SYSTEM ---
    socket.on('createRoom', (data) => {
        // THE FIX: Force-clean any ghost rooms this socket might still be trapped in!
        handlePlayerLeave(socket);

            // Safely extract username whether data is an object or a direct string
        const rawUsername = (typeof data === 'object' && data.username) ? data.username.trim() : (typeof data === 'string' ? data.trim() : "");
        const username = data.username;
        const mapCode = data.mapCode;
        const roomCode = generateRoomCode();
        socket.join(roomCode);

        
        let customState = null;

        if (mapCode) {
            try {
                const decodedStr = Buffer.from(mapCode, 'base64').toString('utf8');
                const parsedBuildings = JSON.parse(decodedStr);
                
                if (Array.isArray(parsedBuildings) && parsedBuildings.length > 0) {
                    // [NEW FIX] Sanitize and lock the map data instantly upon loading
                    parsedBuildings.forEach(b => {
                        if (b.type === 'basic') {
                            b.level = 1; // Basic units never have levels
                        } else if (BUILDING_CONFIGS[b.type]) {
                            // Find the highest available level for this specific type (e.g., Lab is 3)
                            const availableLevels = Object.keys(BUILDING_CONFIGS[b.type]).map(Number).filter(n => !isNaN(n));
                            const maxLevel = Math.max(...availableLevels);
                            
                            // If the level from the editor is higher than the max, clamp it down
                            if (b.level > maxLevel || !BUILDING_CONFIGS[b.type][b.level]) {
                                b.level = maxLevel; 
                            }
                        }
                    });

                    customState = {
                        buildings: parsedBuildings,
                        packages: [],
                        projectiles: []
                    };
                    console.log(`🗺️ Custom Map Loaded for Room ${roomCode}`);
                }
            } catch (e) {
                console.log(`⚠️ Invalid map code provided for Room ${roomCode}. Falling back to default.`);
            }
        }
        
        rooms[roomCode] = {
            host: socket.id,
            players: {}, 
            availableIds: [1, 2, 3, 4],
            state: customState || { buildings: [], packages: [], projectiles: [] },
            playing: false,
            mapName: null,
            bannedUsers: {},
            allowGuestSlotChange: false, // NEW: Toggle property
            unlockedCamera: false, // NEW STATE!
        };
        
        const playerId = rooms[roomCode].availableIds.shift();
        const finalName = rawUsername !== "" ? rawUsername : `Player 1`;
        
        rooms[roomCode].players[socket.id] = { 
            name: finalName, 
            id: playerId, 
            socketId: socket.id, 
            ip: getClientIp(socket) 
        };

        socket.emit('roomCreated', roomCode);
        
        // Pass "hasMap" so the client knows if the Start Game button should be visible
        io.to(roomCode).emit('lobbyUpdate', { 
            allowGuestSlotChange: false, // <-- THE FIX: Send the toggles!
            unlockedCamera: false,       // <-- THE FIX
            players: Object.values(rooms[roomCode].players), 
            host: rooms[roomCode].host,
            hasMap: rooms[roomCode].state.buildings.length > 0 ,
            mapData: rooms[roomCode].state
        });
        socket.emit('initPlayer', playerId);
    });

    // --- PAUSE & READY SYSTEM ---
    socket.on('requestPause', () => {
        const roomCode = getPlayerRoom(socket);
        if (!roomCode || !rooms[roomCode] || !rooms[roomCode].playing) return;
        const room = rooms[roomCode];

        // THE SERVER FAILSAFE: Reject the action if the room is paused!
        if (room.paused) {
            return; 
        }

        if (room.host === socket.id) {
            // The Host paused the game!
            room.paused = true;
            room.readyStates = {}; // Clear previous ready states
            
            io.to(roomCode).emit('gamePaused', { hostName: room.players[room.host].name });
        } else {
            // A Guest is politely asking for a pause
            io.to(roomCode).emit('showNotification', `${room.players[socket.id].name} is requesting a pause!`);
        }
    });

    // --- CAMERA TOGGLE ---
    socket.on('toggleCamera', (isUnlocked) => {
        const code = getPlayerRoom(socket);
        if (code && rooms[code] && rooms[code].host === socket.id) {
            rooms[code].unlockedCamera = isUnlocked;
            
            // Broadcast to everyone
            const hasMapSelected = (rooms[code].state && rooms[code].state.buildings) ? rooms[code].state.buildings.length > 0 : false;
            io.to(code).emit('lobbyUpdate', {
                allowGuestSlotChange: rooms[code].allowGuestSlotChange,
                unlockedCamera: rooms[code].unlockedCamera, // ADD THIS
                players: Object.values(rooms[code].players),
                host: rooms[code].host,
                hasMap: hasMapSelected,
                mapName: rooms[code].mapName,
                mapData: rooms[code].state
            });
        }
    });

    socket.on('toggleReady', (isReady) => {
        const roomCode = getPlayerRoom(socket);
        if (!roomCode || !rooms[roomCode]) return;
        const room = rooms[roomCode];

        room.readyStates[socket.id] = isReady;
        
        // Broadcast the new ready states so everyone's UI updates
        io.to(roomCode).emit('pauseMenuUpdate', room.readyStates);

        // Check if ALL Active Players (Slots 1-4) are ready. Spectators (Slot 5) are ignored!
        const allActivePlayersReady = Object.values(room.players).every(p => {
            if (p.id === 5) return true; 
            return room.readyStates[p.socketId] === true;
        });

        if (allActivePlayersReady) {
            io.to(roomCode).emit('resumeCountdown');
        }
    });

    socket.on('resumeGameFinished', () => {
        // Only the host unlocks the physics engine once the countdown hits zero
        const roomCode = getPlayerRoom(socket);
        if (roomCode && rooms[roomCode] && rooms[roomCode].host === socket.id) {
            rooms[roomCode].paused = false;
        }
    });

// Helper to extract the real IP address
    function getClientIp(socket) {
        const forwarded = socket.handshake.headers['x-forwarded-for'];
        const ip = forwarded ? forwarded.split(',')[0] : socket.handshake.address;
        return ip;
    }

    socket.on('joinRoom', (data) => {
        // THE FIX: Force-clean ghost rooms before joining a new one!
        handlePlayerLeave(socket);
        const code = data.roomCode.toUpperCase();
        const room = rooms[code];
        const clientIp = getClientIp(socket);
        
        // Grab the username, but leave it empty if they didn't type one
        const rawUsername = data.username ? data.username.trim() : "";

        if (room) {
            // THE FIX: Check if their IP is banned!
            if (room.bannedUsers[clientIp] && Date.now() < room.bannedUsers[clientIp]) {
                const remaining = Math.ceil((room.bannedUsers[clientIp] - Date.now()) / 1000);
                socket.emit('errorMsg', `You are banned from this room for ${remaining} more seconds.`);
                return;
            }

            // THE FIX: Removed the "room.availableIds.length > 0" restriction!
            if (!room.playing) {
                socket.join(code);
                
                // Grab an available ID (1-4), or default to 5 (Spectator) if the main slots are full
                const playerId = room.availableIds.length > 0 ? room.availableIds.shift() : 5;
                
                // If they didn't type a name, assign a UNIQUE default name or call them Spectator
                const finalName = rawUsername !== "" ? rawUsername : (playerId === 5 ? `Spectator` : `Player ${playerId}`);
                
                // Save their IP in the player object so the host knows who to ban
                room.players[socket.id] = { 
                    name: finalName, 
                    id: playerId, 
                    socketId: socket.id,
                    ip: clientIp 
                };
                
                socket.emit('roomJoined', code);
                io.to(code).emit('lobbyUpdate', { 
                    allowGuestSlotChange: room.allowGuestSlotChange,
                    unlockedCamera: room.unlockedCamera,
                    players: Object.values(room.players), 
                    host: room.host, 
                    hasMap: room.state.buildings.length > 0,
                    mapName: room.mapName,
                    mapData: room.state 
                });
                socket.emit('initPlayer', playerId);
            } else {
                socket.emit('errorMsg', "Room is already playing.");
            }
        } else {
            socket.emit('errorMsg', "Room not found.");
        }
    });

    // NEW: KICK LOGIC WITH IP BAN
    socket.on('kickPlayer', (targetSocketId) => {
        const roomCode = getPlayerRoom(socket);
        if (!roomCode || !rooms[roomCode]) return;
        const room = rooms[roomCode];

        // Only the host can kick, and ensure the target exists
        if (room.host === socket.id && room.players[targetSocketId]) {
            const targetPlayer = room.players[targetSocketId];

            // THE FIX: Ban their IP Address for 2 minutes (120,000 ms)
            if (targetPlayer.ip) {
                room.bannedUsers[targetPlayer.ip] = Date.now() + 120000;
            }

            // Notify the kicked player directly
            io.to(targetSocketId).emit('kicked');

            // Force them to leave the Socket room
            const ioSocket = io.sockets.sockets.get(targetSocketId);
            if (ioSocket) ioSocket.leave(roomCode);

            // Clean up the room's memory
            // THE FIX: Only put playable IDs (1-4) back into the pool. 5 is infinite!
            if (targetPlayer.id !== 5) {
                room.availableIds.push(targetPlayer.id);
                room.availableIds.sort();
            }
            delete room.players[targetSocketId];
            // Refresh the lobby for everyone else
            io.to(roomCode).emit('lobbyUpdate', {
                players: Object.values(room.players),
                host: room.host,
                hasMap: room.state.buildings.length > 0,
                mapName: room.mapName,
                mapData: room.state,
                allowGuestSlotChange: room.allowGuestSlotChange,
                unlockedCamera: room.unlockedCamera ,       // <-- THE FIX
            });
        }
    });

    socket.on('startGame', () => {
        const roomCode = getPlayerRoom(socket);
        if (roomCode && rooms[roomCode] && rooms[roomCode].host === socket.id) {
            rooms[roomCode].playing = true;
            io.to(roomCode).emit('gameStarted', rooms[roomCode].state);
        }
    });

// --- GAME ACTIONS ---
    socket.on('playerAction', (action) => {
        const roomCode = getPlayerRoom(socket);
        if (!roomCode || !rooms[roomCode] || !rooms[roomCode].playing) return;
        
        const state = rooms[roomCode].state;
        const room = rooms[roomCode];

        // THE SERVER FAILSAFE: Reject the action if the room is paused!
        if (room.paused) {
            return; 
        }

        // 1. Gérer les améliorations
        if (action.action === 'UPGRADE') {
            const b = state.buildings.find(b => b.id === action.buildingId);
            if (!b) return;

            if (b.type === 'basic') {
                const opt = BUILDING_CONFIGS.basic.upgrades.find(u => u.target === action.targetType);
                if (opt && b.jellyCount >= opt.cost) {
                    b.jellyCount -= opt.cost;
                    b.type = action.targetType;
                    b.level = 1;
                }
            } else if (['building', 'fort', 'lab'].includes(b.type)) {
                const config = BUILDING_CONFIGS[b.type][b.level];
                if (config && config.upgradeCost !== null && b.jellyCount >= config.upgradeCost) {
                    b.jellyCount -= config.upgradeCost;
                    b.level += 1;
                }
            }
        }

        // 2. Gérer la préparation des potions
        if (action.action === 'PREPARE_POTION') {
            const b = state.buildings.find(b => b.id === action.buildingId);
            if (b && b.type === 'lab' && !b.activePotion) {
                const pConfig = POTION_CONFIGS[action.potionType];
                if (pConfig && b.jellyCount >= pConfig.cost) {
                    b.activePotion = { type: action.potionType, ready: false };
                    b.potionProgress = 0;
                    b.potionRatio = 0;
                }
            }
        }

        // 3. Gérer l'annulation des potions [CORRIGÉ]
        if (action.action === 'CANCEL_POTION') {
            const b = state.buildings.find(b => b.id === action.buildingId);
            if (b && b.type === 'lab' && b.activePotion) {
                b.activePotion = null;
                b.potionProgress = 0;
                b.potionRatio = 0;
            }
        }

        // 4. Gérer l'envoi des troupes
if (action.action === 'SEND_TROOPS') {
            const senderId = rooms[roomCode].players[socket.id].id;
            const target = state.buildings.find(b => b.id === action.targetId);

            if (target) {
                // Smart multiplier: if client sends 0.5, use 0.5. If client sends 50, do 50/100.
                let rawPerc = action.percentage || 0.5;
                let multiplier = rawPerc > 1 ? rawPerc / 100 : rawPerc; 

                action.sourceIds.forEach(id => {
                    const building = state.buildings.find(b => b.id === id);
                    
                    if (building && building.ownerId === senderId && building.jellyCount > 0) {
                        const amount = Math.floor(building.jellyCount * multiplier);
                        
                        if (amount > 0) {
                        building.jellyCount -= amount;
                        let maxSpd = 8;
                        if (building.type === 'lab') maxSpd = 12;
                        if (building.type === 'fort') maxSpd = 5;

                        // --- SERVER-SIDE HELP PREDICTION ---
                        if (target.ownerId !== senderId) {
                            let dist = Math.hypot(target.x - building.x, target.y - building.y);
                            let ticksToImpact = dist / maxSpd;
                            
                            let prodRate = 0;
                            // Only real players produce jellies
                            if (target.ownerId > 0) {
                                if (target.type === 'basic') prodRate = BUILDING_CONFIGS.basic.prodRate;
                                else if (BUILDING_CONFIGS[target.type] && BUILDING_CONFIGS[target.type][target.level]) {
                                    prodRate = BUILDING_CONFIGS[target.type][target.level].prodRate;
                                }
                            }
                            
                            let predictedDefense = target.jellyCount + (ticksToImpact * prodRate);
                            let incomingAttack = amount;
                            
                            // Forts dampen the incoming attack value
                            if (target.type === 'fort') {
                                let def = BUILDING_CONFIGS.fort[target.level] ? BUILDING_CONFIGS.fort[target.level].defense : 2.0;
                                incomingAttack /= def;
                            }
                            
                            // 20 ticks = 2 seconds of Help! bubble
                            if (incomingAttack > predictedDefense) {
                                target.helpTimer = 20; 
                            }
                        }
                        const startPoint = getUnitVisualCenter(building);

                        state.packages.push({
                            id: Math.random().toString(36).substr(2, 9),
                            x: startPoint.x, 
                            y: startPoint.y,
                            sourceId: building.id,
                            targetId: action.targetId,
                            ownerId: building.ownerId,
                            jellyCount: amount,
                            maxSpeed: maxSpd,
                            currentSpeed: 1,
                            acceleration: (maxSpd - 1) / 7,
                            vx: 0,
                            vy: 0,
                            // --- NEW ANTI-STUCK VARIABLES ---
                            stuckCheckTimer: 40, // Check every 4 seconds (40 ticks)
                            lastDist: Infinity,  // Tracks distance to target
                            ghostTicks: 0        // How long to disable collisions
                        });
                    }
                    }
                });
            }
        }

        // 5. Gérer l'utilisation d'une potion prête sur une cible
if (action.action === 'USE_POTION') {
            const lab = state.buildings.find(b => b.id === action.labId);
            const target = state.buildings.find(b => b.id === action.targetId);
            const senderId = rooms[roomCode].players[socket.id].id;

            // 1. Ensure Lab exists, is owned by sender, has a ready potion, and isn't targeting itself
            if (lab && lab.type === 'lab' && lab.ownerId === senderId && lab.activePotion && lab.activePotion.ready && target && target.ownerId !== senderId) {
                const pType = lab.activePotion.type;
                const cost = POTION_CONFIGS[pType].cost;

                // 2. Check if the lab actually has enough jellies to fire the potion
                if (lab.jellyCount >= cost) {
                    let isValidTarget = false;

                    // 3. Targeting Rules
                    if ((pType === 'freeze' || pType === 'virus') && target.ownerId > 0) {
                        // Freeze and Virus can ONLY hit real enemy players (> 0)
                        isValidTarget = true; 
                    } else if (pType === 'red') {
                        // Red potion can hit ANYONE except yourself (checked above), including neutrals (0) and frozen (-1)
                        isValidTarget = true; 
                    }

                    if (isValidTarget) {
                        // 4. Deduct the cost from the lab at the exact moment of use!
                        lab.jellyCount -= cost;

                        // Apply potion effects
                        if (pType === 'freeze') {
                            target.ownerId = -1; // Give to dummy "Freeze" player
                            target.status = 'frozen';
                            target.activePotion = null;
                            target.potionProgress = 0;
                            target.potionRatio = 0;
                        } else if (pType === 'virus') {
                            target.status = 'sick';
                        } else if (pType === 'red') {
                            target.ownerId = lab.ownerId; // Capture it!
                            target.status = 'normal';
                            target.activePotion = null;
                            target.potionProgress = 0;
                            target.potionRatio = 0;
                        }

                        // Wipe the used potion from the lab
                        lab.activePotion = null;
                        lab.potionProgress = 0;
                        lab.potionRatio = 0;
                    }
                }
            }
        }
    });

// --- NEW HELPER: Handles both leaving manually and closing the tab ---
    function handlePlayerLeave(socket) {
        for (let code in rooms) {
            if (rooms[code].players[socket.id]) {
                const room = rooms[code];

                // 1. DID THE HOST LEAVE?
                if (room.host === socket.id) {
                    
                    // THE FIX: Use 'socket.to()' to send to everyone EXCEPT the host!
                    socket.to(code).emit('hostDisconnected', "The host closed the room.");
                    
                    // Force all sockets to leave the technical socket.io room
                    io.in(code).socketsLeave(code);
                    
                    // Delete the room from memory completely
                    delete rooms[code];
                } 
                // 2. A GUEST LEFT
                else {
                    const idToFree = room.players[socket.id].id;
                    
                    // THE FIX: Only recycle playable IDs (1-4)
                    if (idToFree !== 5) {
                        room.availableIds.push(idToFree);
                        room.availableIds.sort();
                    }
                    
                    delete room.players[socket.id];
                    
                    socket.leave(code); // Remove them from the socket.io room                    
                    // Update the lobby for the remaining players
                    io.to(code).emit('lobbyUpdate', { 
                        players: Object.values(room.players), 
                        host: room.host,
                        hasMap: room.state.buildings.length > 0,
                        mapName: room.mapName,
                        mapData: room.state 
                    });
                }
                break;
            }
        }
    }

    // HOST TOGGLE: Allow guests to move themselves
    socket.on('toggleGuestSlotChange', (enabled) => {
        const roomCode = getPlayerRoom(socket);
        if (roomCode && rooms[roomCode] && rooms[roomCode].host === socket.id) {
            rooms[roomCode].allowGuestSlotChange = enabled;
            // Broadcast the UI update
            io.to(roomCode).emit('lobbyUpdate', {
                players: Object.values(rooms[roomCode].players),
                host: rooms[roomCode].host,
                hasMap: rooms[roomCode].state.buildings.length > 0,
                mapName: rooms[roomCode].mapName,
                mapData: rooms[roomCode].state,
                allowGuestSlotChange: enabled
            });
        }
    });

    // DRAG AND DROP LOGIC
    socket.on('changeSlot', (data) => {
        const roomCode = getPlayerRoom(socket);
        if (!roomCode || !rooms[roomCode]) return;
        const room = rooms[roomCode];
        const isHost = room.host === socket.id;

        const sourceSocketId = data.sourceSocketId;
        const targetSlot = parseInt(data.targetSlot, 10); // 1, 2, 3, 4, or 5 (Spectator)

        // Security: Guests can only move themselves, and only if the host allows it!
        if (!isHost && sourceSocketId !== socket.id) return;
        if (!isHost && !room.allowGuestSlotChange) return;

        const sourcePlayer = room.players[sourceSocketId];
        if (!sourcePlayer || sourcePlayer.id === targetSlot) return; // No change needed

        // THE FIX: We MUST save the old slot before we change it, so we can give it to the occupant!
        const oldSlot = sourcePlayer.id; 

        // Find if target slot is occupied (Slot 5 can hold infinite spectators)
        let occupantSocketId = null;
        if (targetSlot !== 5) {
            for (let sid in room.players) {
                if (room.players[sid].id === targetSlot) {
                    occupantSocketId = sid;
                    break;
                }
            }
        }

        if (occupantSocketId) {
            // SECURITY: Guests CANNOT swap places with occupied slots!
            if (!isHost) return; 
            
            // Host SWAPS the two players
            const occupant = room.players[occupantSocketId];
            sourcePlayer.id = targetSlot;
            
            // THE FIX: Give the occupant the saved old slot, not the new one!
            occupant.id = oldSlot; 
        } else {
            // Move player to the empty slot
            sourcePlayer.id = targetSlot;
        }

        // Recalculate available playable IDs (1-4)
        room.availableIds = [1, 2, 3, 4].filter(id => {
            return !Object.values(room.players).some(p => p.id === id);
        });

        // THE CRASH FIX: Safely check if a map exists before checking its length!
        const hasMapSelected = (room.state && room.state.buildings) ? room.state.buildings.length > 0 : false;

        io.to(roomCode).emit('lobbyUpdate', {
            players: Object.values(room.players),
            host: room.host,
            hasMap: hasMapSelected,
            mapName: room.mapName,
            mapData: room.state,
            allowGuestSlotChange: room.allowGuestSlotChange
        });
    });

    // Triggered when clicking "Back"
    socket.on('leaveRoom', () => {
        handlePlayerLeave(socket);
    });

    // Triggered when closing the browser tab
    socket.on('disconnect', () => {
        handlePlayerLeave(socket);
    });
});

// --- MAIN SERVER LOGIC LOOP ---
// --- MAIN SERVER LOGIC LOOP (Physics & Physics) ---
setInterval(() => {
    for (let code in rooms) {
        let room = rooms[code];
        if (!room.playing) continue; 

        if (rooms[code].paused) return;


        // 1. Clear previous frame's visual lasers
        room.state.lasers = [];

        // 2. Building Logic (Production, Decay, Potions)
        room.state.buildings.forEach(b => {
            if (b.helpTimer > 0) b.helpTimer--; // Count down the Help bubble
            if (b.status === 'sick') { b.jellyCount = Math.max(0, b.jellyCount - 0.1); return; }
            if (b.status === 'frozen') return;

            if (b.type === 'lab' && b.activePotion) {
                const pConfig = POTION_CONFIGS[b.activePotion.type];
                if (b.jellyCount < pConfig.cost) {
                    b.activePotion = null; b.potionProgress = 0; b.potionRatio = 0;
                } else if (!b.activePotion.ready) {
                    b.potionProgress += 1;
                    b.potionRatio = b.potionProgress / pConfig.craftDurationTicks;
                    if (b.potionProgress >= pConfig.craftDurationTicks) {
                        b.activePotion.ready = true; b.potionRatio = 1;
                    }
                }
            }

            // [FIX] Only real players (ID 1, 2, 3, 4) produce/decay. 
            // Neutrals (0) and Frozen (-1) do nothing.
            if (b.ownerId > 0) {
                let max, rate;
                
                if (b.type === 'basic') {
                    max = BUILDING_CONFIGS.basic.maxJellies;
                    rate = BUILDING_CONFIGS.basic.prodRate;
                } else {
                    // Smart Fallback
                    if (!BUILDING_CONFIGS[b.type][b.level]) {
                        const availableLevels = Object.keys(BUILDING_CONFIGS[b.type]).map(Number).filter(n => !isNaN(n));
                        b.level = Math.max(...availableLevels); 
                    }
                    max = BUILDING_CONFIGS[b.type][b.level].maxJellies;
                    rate = BUILDING_CONFIGS[b.type][b.level].prodRate;
                }

                if (b.maxJelliesOverride) {
                    max = b.maxJelliesOverride;
                }

                if (b.jellyCount > max) {
                    b.jellyCount = Math.max(max, b.jellyCount - 0.1);
                } else if (b.jellyCount < max && (b.type === 'basic' || b.type === 'building')) {
                    b.jellyCount = Math.min(max, b.jellyCount + rate);
                }
            }
        });
// 3. Move Packages & Handle Capture Math
        for (let i = room.state.packages.length - 1; i >= 0; i--) {
            let p = room.state.packages[i];
            const target = room.state.buildings.find(b => b.id === p.targetId);
            
            // THE FIX: Check if the target exists BEFORE trying to calculate its center!
            if (!target) { room.state.packages.splice(i, 1); continue; }
            
            const targetxy = getUnitVisualCenter(target);

            const dx = targetxy.x - p.x;
            const dy = targetxy.y - p.y;
            const dist = Math.sqrt(dx*dx + dy*dy);
            
            // Has it arrived?
            if (dist <= target.radius) {
                if (target.ownerId === p.ownerId) {
                    target.jellyCount += p.jellyCount;
                } else {
                    // --- NEW CAPTURE MATH ---
                    let defenseMultiplier = 1;
                    
                    // Pull the exact defense stat from the config (e.g., L3 = 4.0)
                    if (target.type === 'fort' && BUILDING_CONFIGS.fort[target.level]) {
                        defenseMultiplier = BUILDING_CONFIGS.fort[target.level].defense;
                    }

                    let jellyCostToDefeat = target.jellyCount * defenseMultiplier;

                    if (p.jellyCount > jellyCostToDefeat) {
                        // The fort is captured!
                        let remainingJellies = p.jellyCount - jellyCostToDefeat;
                        target.ownerId = p.ownerId;
                        target.jellyCount = remainingJellies; // The remainder stays
                        target.activePotion = null;
                        target.potionProgress = 0;
                        target.potionRatio = 0;
                        target.status = 'normal';
                    } else {
                        // The attack failed, reduce the fort's health
                        let defendersKilled = Math.floor(p.jellyCount / defenseMultiplier);
                        target.jellyCount -= defendersKilled;
                        if (target.jellyCount < 0) target.jellyCount = 0;
                    }
                }
                room.state.packages.splice(i, 1);
                continue; 
            }
            
            // ==========================================
            // SAFE PHYSICS ENGINE
            // ==========================================

            if (p.currentSpeed < p.maxSpeed) {
                p.currentSpeed = Math.min(p.maxSpeed, p.currentSpeed + p.acceleration);
            }

// Fallback to prevent NaN if distance is somehow 0
            let safeDist = dist === 0 ? 0.001 : dist;
            let dirX = dx / safeDist; 
            let dirY = dy / safeDist;

            // ==========================================
            // NEW: ANTI-STUCK MECHANISM ("Ghost Mode")
            // ==========================================
            if (p.lastDist === Infinity) p.lastDist = dist;

            if (p.ghostTicks > 0) {
                p.ghostTicks--; // Count down the ghost timer
            } else {
                p.stuckCheckTimer--;
                if (p.stuckCheckTimer <= 0) {
                    // It's been 4 seconds. Did we move at least 20 pixels closer to the target?
                    if (p.lastDist - dist < 20) {
                        p.ghostTicks = 20; // Yes we are stuck! Become a ghost for 2 seconds!
                    }
                    p.lastDist = dist; // Set the new benchmark
                    p.stuckCheckTimer = 40; // Reset the 4-second clock
                }
            }

            // --- 3. Calculate Repulsion & BOUNCE ---
            let repX = 0;
            let repY = 0;
            
            // ONLY check for building collisions if we are NOT a ghost!
            if (p.ghostTicks === 0) {
                const avoidancePadding = 8; // La zone où il commence à glisser


            room.state.buildings.forEach(b => {
                if (b.id === target.id || b.id === p.sourceId) return; 

                let bx = p.x - b.x;
                let by = p.y - b.y;
                let bDist = Math.sqrt(bx * bx + by * by);
                
                if (bDist === 0) {
                    bx = 0.1; by = 0.1; bDist = 0.14; 
                }

                let avoidRadius = b.radius + avoidancePadding;

                if (bDist < avoidRadius) {
                    let strength = (avoidRadius - bDist) / avoidRadius;
                    
                    let normX = bx / bDist;
                    let normY = by / bDist;
                    
                    let tan1X = -normY;
                    let tan1Y = normX;
                    let tan2X = normY;
                    let tan2Y = -normX;
                    
                    let dot1 = tan1X * dirX + tan1Y * dirY;
                    let dot2 = tan2X * dirX + tan2Y * dirY;
                    
                    let bestTanX, bestTanY;

                    // Briseur de Symétrie
                    if (Math.abs(dot1 - dot2) < 0.05) {
                        const parity = p.id.charCodeAt(0) % 2 === 0;
                        bestTanX = parity ? tan1X : tan2X;
                        bestTanY = parity ? tan1Y : tan2Y;
                    } else {
                        bestTanX = dot1 > dot2 ? tan1X : tan2X;
                        bestTanY = dot1 > dot2 ? tan1Y : tan2Y;
                    }
                    
                    // [NEW] Mécanique de Rebond Physique !
                    let outwardForce = 1.5; // Force de glissement normale
                    let slideForce = 8; // Force de glissement tangentielle
                    
                    // Si le package percute physiquement le bâtiment (à moins de 3 pixels du bord)
                    if (bDist < b.radius + 3) {
                        // Force de répulsion massive pour simuler le choc physique (le projette en arrière)
                        outwardForce = 20.0; 
                        // Transfert d'énergie : il perd sa vitesse à l'impact et devra réaccélérer avec l'inertie
                        p.currentSpeed = Math.max(2, p.currentSpeed * 0.7); 
                    }
                    
                    repX += (normX * outwardForce + bestTanX * slideForce) * strength; 
                    repY += (normY * outwardForce + bestTanY * slideForce) * strength;
                }
            });
        }

            let finalVx = dirX + repX;
            let finalVy = dirY + repY;
            let finalDist = Math.sqrt(finalVx * finalVx + finalVy * finalVy);

            if (finalDist > 0) {
                p.vx = (finalVx / finalDist) * p.currentSpeed;
                p.vy = (finalVy / finalDist) * p.currentSpeed;
            }

            p.x += p.vx;
            p.y += p.vy;
        }
// 4. Fort Defenses (Spawning Homing Projectiles)
        room.state.buildings.forEach(b => {
            // [FIX] The Fort will ONLY shoot if owned by a real player (> 0) and NOT frozen
            if (b.type === 'fort' && b.status !== 'frozen') {
                if (b.currentCooldown === undefined) b.currentCooldown = 0;         
                       
                if (b.currentCooldown > 0) {
                    b.currentCooldown--;
                    return; 
                }

                const attackRadius = b.radius * 6;
                let nearestPackage = null;
                let minDist = attackRadius;
                
                room.state.packages.forEach(p => {
                    if (p.ownerId !== b.ownerId) {
                        const pDist = Math.sqrt(Math.pow(p.x - b.x, 2) + Math.pow(p.y - b.y, 2));
                        if (pDist <= minDist) {
                            minDist = pDist;
                            nearestPackage = p;
                        }
                    }
                });
                if (nearestPackage) {
                    const fortPoint = getUnitVisualCenter(b);
                    // Spawn a tracking projectile instead of dealing instant damage
                    room.state.projectiles.push({
                        id: Math.random().toString(36).substr(2, 9),
                        x: fortPoint.x,  
                        y: fortPoint.y,
                        targetPackageId: nearestPackage.id,
                        ownerId: b.ownerId,
                        speed: 28, // Faster than normal packages (which are speed 8)
                        damage: 2
                    });
                    
                    const config = BUILDING_CONFIGS.fort[b.level] || BUILDING_CONFIGS.fort[1];
                    b.currentCooldown = config.cooldownTicks;
                }
            }
        });

        // 5. Move Projectiles & Handle Hits
        for (let i = room.state.projectiles.length - 1; i >= 0; i--) {
            let proj = room.state.projectiles[i];
            const targetPkg = room.state.packages.find(p => p.id === proj.targetPackageId);
            
            // If the package was destroyed or captured a base before the projectile hit it, destroy the projectile
            if (!targetPkg) {
                room.state.projectiles.splice(i, 1);
                continue;
            }
            
            const dx = targetPkg.x - proj.x;
            const dy = targetPkg.y - proj.y;
            const dist = Math.sqrt(dx*dx + dy*dy);
            
            // If it hits the package (14 is the visual radius of the package)
            if (dist <= 14) {
                targetPkg.jellyCount -= proj.damage;
                room.state.projectiles.splice(i, 1); // Delete projectile on impact
            } else {
                // Keep homing in on the package, even if outside the Fort's radius!
                const angle = Math.atan2(dy, dx);
                proj.x += Math.cos(angle) * proj.speed;
                proj.y += Math.sin(angle) * proj.speed;
            }
        }

        // 6. Clean up destroyed packages (moved to the very end so projectiles can hit them first)
        room.state.packages = room.state.packages.filter(p => p.jellyCount > 0);
        
        io.to(code).emit('syncState', { 
            ...room.state, 
            unlockedCamera: room.unlockedCamera 
        });
    }
}, 100);

// --- GLOBAL SERVER HEARTBEAT ---
setInterval(() => {
    const now = Date.now();
    
    // 1. Send a Ping Request to every connected socket
    io.emit('pingRequest', now);

    // 2. Broadcast live Scoreboard data to every ACTIVE room
    for (let code in rooms) {
        if (rooms[code].playing) {
            const scoreboardData = Object.values(rooms[code].players).map(p => ({
                name: p.name,
                id: p.id,
                ping: p.ping || 0, // Default to 0 if they haven't pinged yet
                socketId: p.socketId
            })).sort((a, b) => a.id - b.id); // Sort by player slot
            
            io.to(code).emit('scoreboardUpdate', scoreboardData);
        }
    }
}, 2000);

server.listen(3000, () => {
    console.log('🚀 Server active on http://localhost:3000');
});